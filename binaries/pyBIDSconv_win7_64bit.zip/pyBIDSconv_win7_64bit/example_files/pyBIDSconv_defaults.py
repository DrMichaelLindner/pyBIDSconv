
default_categorization_file = 'G:\Dropbox\Dropbox\pyBIDSconv\example_files\pyBVIDSconv_CINNcatagorisation.txt'
default_config_file = 'G:\Dropbox\Dropbox\pyBIDSconv\example_files\pyBIDSconv_CINNconfig.py'