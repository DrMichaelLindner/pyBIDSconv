
ReconstructionInfoInImageType = ['NORM', 'MOCO']

PhaseInfoForFmapsBySequenceDescriptionSubstring = ["_pa", "_ap", "_rl", "_lr"]

ExclusionsBySequenceDescriptionContent = ['aah', 'scout', 'phoenix']

ExclusionsBySequenceDescriptionEnd = [ 'Localizer', '_fa', '_trace', '_colfa', '_tracew', '_adc']
